﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp19
{
    public partial class Form2 : Form
    {
        private static string ConnStr = @"SslMode=none;
                                        server=127.0.0.1;
                                        port=3306;                                      
                                        username=root;
                                        password=19501950;
                                        database=Apteka1"; //Строка подключения к серверу
        private static MySqlConnection Conn = new MySqlConnection(ConnStr); // создаём объект для подключения к БД
        public Form2(int caseSwitch, string login)
        {
            InitializeComponent();

            label1.Text = ("Пользователь: " + login);

            switch (caseSwitch)
            {
                case 1:
                    panel3.BackColor = Color.FromArgb(151, 109, 158);
                    break;
                case 2:
                    panel3.BackColor = Color.FromArgb(99, 99, 172);
                    break;
                case 3:
                    panel3.BackColor = Color.FromArgb(129, 147, 177);
                    break;
                case 4:
                    panel3.BackColor = Color.FromArgb(185, 123, 167);
                    break;
                case 5:
                    panel3.BackColor = Color.FromArgb(78, 68, 100);
                    break;
                default:
                    panel3.BackColor = Color.FromArgb(38, 38, 6);
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
        }
        string text;
        private void Form2_Load(object sender, EventArgs e)
        {
            Conn.Open();

            MySqlCommand cmd1 = Conn.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "SELECT * FROM Apteka1.товары";
            cmd1.ExecuteNonQuery();
            Conn.Close();
            DataTable dt1 = new DataTable();
            MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
            da1.Fill(dt1);
            dataGridView1.DataSource = dt1;

            Conn.Close();
            String x;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                DataGridViewRow row = dataGridView1.Rows[i];
                if (!row.IsNewRow)
                {
                    x = row.Cells[0].Value.ToString() + " " + row.Cells[1].Value.ToString();
                    listBox1.Items.Add(x);
                }
            }
            label2.Text = "Мукалтин";
            label3.Text = Convert.ToString(dataGridView1.Rows[0].Cells[2].Value);
            label4.Text = Convert.ToString(dataGridView1.Rows[0].Cells[4].Value);
            label5.Text = ("Дата изготовления: " + Convert.ToString(dataGridView1.Rows[0].Cells[5].Value));
            label6.Text = ("Дата просрочки: " + Convert.ToString(dataGridView1.Rows[0].Cells[6].Value));
            label7.Text = ("Количество на складе: " + Convert.ToString(dataGridView1.Rows[0].Cells[7].Value));
            textBox2.Text = Convert.ToString(dataGridView1.Rows[0].Cells[3].Value);
        }

        public void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string s = listBox1.SelectedItem.ToString();
                var res = s.ToCharArray().Where(n => !char.IsDigit(n)).ToArray();
                string text = new string(res);

                String query = "SELECT * FROM `товары` WHERE `Название_Товара` LIKE '%" + Convert.ToString(text.TrimStart()) + "'";
                //Console.WriteLine(query);
                command = new MySqlCommand(query, Conn);
                adapter = new MySqlDataAdapter(command);
                table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;

                label2.Text = text;
                label3.Text = Convert.ToString(dataGridView1.Rows[0].Cells[2].Value);
                label4.Text = Convert.ToString(dataGridView1.Rows[0].Cells[4].Value);
                label5.Text = ("Дата изготовления: " + Convert.ToString(dataGridView1.Rows[0].Cells[5].Value));
                label6.Text = ("Дата просрочки: " + Convert.ToString(dataGridView1.Rows[0].Cells[6].Value));
                label7.Text = ("Количество на складе: " + Convert.ToString(dataGridView1.Rows[0].Cells[7].Value));
                textBox2.Text = Convert.ToString(dataGridView1.Rows[0].Cells[3].Value);
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if(label2.Text == "Название:")
            {
                MessageBox.Show("Выберите товар");
            }
            if (numericUpDown1.Value == 0)
            {
                MessageBox.Show("Вы не указали количество товара");
            }
            if (numericUpDown1.Value >= 1)
            {
                string x;
                x = label2.Text.ToString() + "/" + numericUpDown1.Value.ToString() + "" + "шт";
                listBox2.Items.Add(x);
                MessageBox.Show("Товар добавлен в корзину");
                button4.Enabled = true;
                //button4.Image = Properties.Resources;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string ValuseDASearch = textBox1.Text.ToString();
            SearchData(ValuseDASearch);
        }
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable table;
        public void SearchData(string ValuseDASearch)
        {
            try
            {
                String query = "SELECT * FROM `товары` WHERE `Название_Товара` LIKE '%" + ValuseDASearch + "%'";
                command = new MySqlCommand(query, Conn);
                adapter = new MySqlDataAdapter(command);
                table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
            catch
            {

            }
        }

        private void listBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                if (listBox1.SelectedItem != null)
                {
                    string s = listBox1.SelectedItem.ToString();
                    var res = s.ToCharArray().Where(n => !char.IsDigit(n)).ToArray();
                    string text = new string(res);

                    String query = "SELECT * FROM `товары` WHERE `Название_Товара` LIKE '%" + Convert.ToString(text.TrimStart()) + "'";
                    //Console.WriteLine(query);
                    command = new MySqlCommand(query, Conn);
                    adapter = new MySqlDataAdapter(command);
                    table = new DataTable();
                    adapter.Fill(table);
                    dataGridView1.DataSource = table;

                    label2.Text = text;
                    label3.Text = Convert.ToString(dataGridView1.Rows[0].Cells[2].Value);
                    label4.Text = Convert.ToString(dataGridView1.Rows[0].Cells[4].Value);
                    label5.Text = ("Дата изготовления: " + Convert.ToString(dataGridView1.Rows[0].Cells[5].Value));
                    label6.Text = ("Дата просрочки: " + Convert.ToString(dataGridView1.Rows[0].Cells[6].Value));
                    label7.Text = ("Количество на складе: " + Convert.ToString(dataGridView1.Rows[0].Cells[7].Value));
                    textBox2.Text = Convert.ToString(dataGridView1.Rows[0].Cells[3].Value);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Conn.Open();

            MySqlCommand cmd1 = Conn.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "SELECT * FROM Apteka1.товары";
            cmd1.ExecuteNonQuery();
            Conn.Close();
            DataTable dt1 = new DataTable();
            MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
            da1.Fill(dt1);
            dataGridView1.DataSource = dt1;

            Conn.Close();

            listBox1.Items.Clear();

            String x;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                DataGridViewRow row = dataGridView1.Rows[i];
                if (!row.IsNewRow)
                {
                    x = row.Cells[0].Value.ToString() + " " + row.Cells[1].Value.ToString();
                    listBox1.Items.Add(x);
                }
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            panel5.Location = new Point(12, 51);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel5.Location = new Point(1200, 51);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            text = String.Empty;
            string ALF = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
            for (int i = 0; i < 10; ++i)
                text += ALF[rnd.Next(ALF.Length)];
            if (textBox3.Text == "" || textBox4.Text == ""|| textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "")
            {
                MessageBox.Show("Заполните все поля");
            }
            if (listBox2.Items == null)
            {
                MessageBox.Show("Вы не добавили товар");
            }           
            Console.WriteLine(text);
            if (listBox2.Items.Count == 0)
            {
                MessageBox.Show("Вы не добавили товар в корзину");
            }
            if (listBox2.Items.Count >= 1)
            {
                int sss = listBox2.Items.Count;
                int sss1 = sss - 1;
                listBox2.Items.Insert(sss, "Конец списка" + text);
                string x1;
                for (int x = 0; x <= sss1; x++)
                {
                    x1 = listBox2.Items[x].ToString();

                    string x2 = Convert.ToString(x1.Length - 4);

                    string a = x1;
                    int value;
                    int.TryParse(string.Join("", a.Where(c => char.IsDigit(c))), out value);

                    Console.WriteLine(x1);
                    Console.WriteLine(value);
                    Conn.Open();

                    MySqlCommand cmd1 = Conn.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = "INSERT INTO `Apteka1`.`корзина` (`Номер_Заказа`,`Название_Товара`, `Количество_Товара`, `Фамилия`, `Имя`, `Отчество`, `Адрес`, `Номер_телефона`, `Км`, `Цена_Доставки`) " +
                        "VALUES ('" + text + "','" + x1 + "', '" + value + "', '" + textBox4.Text + "', '" + textBox3.Text + "', '" + textBox5.Text + "', '" + textBox7.Text + "', '" + textBox6.Text + "', '" + textBox8.Text + "', '" + label15.Text + "')";
                    // объект для выполнения SQL-запроса
                    cmd1.ExecuteNonQuery();
                    Conn.Close();
                }
                MessageBox.Show("Заказ добавлен" + "/ Номер заказа:" + text);
                listBox2.Items.Clear();
            }
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 47 || e.KeyChar >= 58)
            {
                if (e.KeyChar <= 07 || e.KeyChar >= 09)
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 47 || e.KeyChar >= 58)
            {
                if (e.KeyChar <= 07 || e.KeyChar >= 09)
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 1000 || e.KeyChar >= 1300)
            {
                if (e.KeyChar <= 07 || e.KeyChar >= 09)
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar <= 1000 || e.KeyChar >= 1300)
            {
                if (e.KeyChar <= 1 || e.KeyChar >= 33)
                {
                    if (e.KeyChar <= 47 || e.KeyChar >= 58)
                    {
                        if (e.KeyChar <= 7 || e.KeyChar >= 9)
                        {
                            if (e.KeyChar <= 43 || e.KeyChar >= 46)
                            {
                                e.Handled = true;
                            }
                        }
                    }
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (textBox8.Text == "")
            {

            }
            else
            {
                int s = 0;
                label1.Text = Convert.ToString(s);
                string s1 = textBox8.Text;
                int s2 = 30;
                int s3 = Convert.ToInt32(s1) * s2;
                label15.Text = Convert.ToString(s3);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string s = listBox1.SelectedItem.ToString();
                var res = s.ToCharArray().Where(n => !char.IsDigit(n)).ToArray();
                string text = new string(res);

                String query = "SELECT * FROM `товары` WHERE `Название_Товара` LIKE '%" + Convert.ToString(text.TrimStart()) + "'";
                //Console.WriteLine(query);
                command = new MySqlCommand(query, Conn);
                adapter = new MySqlDataAdapter(command);
                table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;

                label2.Text = text;
                label3.Text = Convert.ToString(dataGridView1.Rows[0].Cells[2].Value);
                label4.Text = Convert.ToString(dataGridView1.Rows[0].Cells[4].Value);
                label5.Text = ("Дата изготовления: " + Convert.ToString(dataGridView1.Rows[0].Cells[5].Value));
                label6.Text = ("Дата просрочки: " + Convert.ToString(dataGridView1.Rows[0].Cells[6].Value));
                label7.Text = ("Количество на складе: " + Convert.ToString(dataGridView1.Rows[0].Cells[7].Value));
                textBox2.Text = Convert.ToString(dataGridView1.Rows[0].Cells[3].Value);
            }
        }
    }
}
