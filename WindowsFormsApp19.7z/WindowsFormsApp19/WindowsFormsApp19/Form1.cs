﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp19
{
    public partial class Form1 : Form
    {
        private static string ConnStr = @"SslMode=none;
                                        server=127.0.0.1;
                                        port=3306;                                      
                                        username=root;
                                        password=19501950;
                                        database=Apteka1"; //Строка подключения к серверу
        private static MySqlConnection Conn = new MySqlConnection(ConnStr); // создаём объект для подключения к БД
        int caseSwitch;
        string login;

        public Form1()
        {
            InitializeComponent();

            // необходимо обязательно указать иконку
            // иначе уведомление не будет отображаться
            // можно использовать иконку формы
            notifyIcon1.Icon = this.Icon;

            // показываем уведомление
            notifyIcon1.ShowBalloonTip(
              500,
              "",
              "Кликните по форме два раза",
              ToolTipIcon.None
            );

            Random rnd = new Random();
            caseSwitch = rnd.Next(1, 1);

            switch (caseSwitch)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.U8T7;
                    break;
                case 2:
                 //   pictureBox1.Image = Properties.Resources.image_86300418003940876320;
                    break;
                case 3:
                  //  pictureBox1.Image = Properties.Resources._3Q2K;
                    break;
                /*case 4:
                    pictureBox1.Image = Properties.Resources.d3e;
                    break;*/
                case 5:
                 //   pictureBox1.Image = Properties.Resources._1K;
                    break;
                default:
                    break;
            }

        }

        private NotifyIcon NI = new NotifyIcon();

        private void NI_BalloonTipClosed(Object sender, EventArgs e)
        {
            NI.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer4.Start();
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                timer6.Start();
                timer7.Start();
            }
            else
            {
                timer5.Start();
                timer7.Start();
            }
        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (panel7.Left != 300)
            {
                panel7.Left += 1;
            }
            if (panel7.Left >= 300)
            {
                timer1.Stop();
                notifyIcon1.Dispose();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                login = textBox1.Text;

                dataGridView1.ClearSelection();

                Conn.Open();

                MySqlCommand cmd1 = Conn.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "SELECT * FROM пользователь WHERE Логин ='" + textBox1.Text + "' AND Пароль = MD5('" + textBox2.Text + "')";
                cmd1.ExecuteNonQuery();
                Conn.Close();
                DataTable dt1 = new DataTable();
                MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                da1.Fill(dt1);
                dataGridView1.DataSource = dt1;
                int B1 = Convert.ToSByte(dataGridView1.Rows[0].Cells[1].Value);

                if (B1 == 99)
                {
                    Form S = new Form2(caseSwitch, login);
                    S.Show();
                }
                if (B1 >= 100 || B1 <= 98)
                {
                    MessageBox.Show("Логин/Пароль не правильный");
                }
            }
            catch
            {
                Conn.Close();
            }

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (panel4.Left != 0)
            {
                panel4.Left += 20;
            }
            if (panel4.Left >= 0)
            {
                timer2.Stop();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (panel4.Left != -350)
            {
                panel4.Left -= 20;
            }
            if (panel4.Left <= -350)
            {
                timer3.Stop();
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {

        }
        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void panel4_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void panel4_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void panel4_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (panel4.Location.X == -350)
            {
                timer2.Start();
            }
            if (panel4.Location.X >= 0)
            {
                timer3.Start();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox4.Text != "" && textBox3.Text != "")
                {
                    int i = 0;

                    Conn.Open();

                    MySqlCommand cmd = Conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT * FROM пользователь WHERE Логин ='" + textBox4.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dt);
                    i = Convert.ToInt32(dt.Rows.Count.ToString());
                    Conn.Close();
                    if (i == 0)
                    {
                        Conn.Open();

                        MySqlCommand cmd1 = Conn.CreateCommand();
                        cmd1.CommandType = CommandType.Text;
                        cmd1.CommandText = "INSERT INTO `Apteka1`.`пользователь` (`Поиск`,`Фамилия`, `Имя`, `Отчество`, `Логин`, `Пароль`) VALUES ('99','Нет данных', 'Нет данных', 'Нет данных', '" + textBox4.Text + "', MD5('" + textBox3.Text + "'))";
                        // объект для выполнения SQL-запроса
                        cmd1.ExecuteNonQuery();
                        Conn.Close();
                        MessageBox.Show("Успешная регистрация");
                    }
                    else
                    {
                        MessageBox.Show("Такой пользователь уже есть");
                        Conn.Close();
                    }
                    Conn.Close();
                }
                else
                    Conn.Close();
            }
            catch
            {
                Conn.Close();
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (button2.Top != 240)
            {
                button2.Top += 5;
            }
            if (button2.Top >= 240)
            {
                timer5.Stop();
                timer7.Stop();
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            if (button2.Top != 200)
            {
                button2.Top -= 5;
            }
            if (button2.Top <= 200)
            {
                timer6.Stop();
                timer7.Stop();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                button2.Location = new Point(361, 200);
                timer5.Stop();
                timer6.Stop();
            }
            else
                button2.Location = new Point(361, 240);
            timer5.Stop();
            timer6.Stop();
        }
    }
}
